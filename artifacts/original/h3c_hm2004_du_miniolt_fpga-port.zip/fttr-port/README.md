# H3C HM2004-DU FTTR master-OLT (FMCS) — reverse engineering and port

Source reconstruction of the "FMCS" FTTR master-OLT subsystem of the H3C
HM2004-DU, so that it can run on the OpenWrt 6.18 / Airoha AN7581 kernel tree
(`qwe3017/ponwrt`) instead of the vendor's Linux 5.4.55 Buildroot image.

Everything here was derived from the artefacts in `D:\H3C\bak\mtd3_rootfs` and
`D:\H3C\bak\mtd2_kernel.bin`. The evidence for every constant, register frame
and GPIO bit is recorded in [`docs/REVERSE_ENGINEERING.md`](docs/REVERSE_ENGINEERING.md).

---

## What the subsystem is

The HM2004-DU is an FTTR **main** gateway. Besides the normal G-PON uplink it
carries a second, H3C-proprietary PON built around a **Pango Logos PGL50H**
FPGA that acts as master OLT for up to sixteen sub-ONUs:

```
        userspace                      kernel                        hardware
  ┌────────────────────┐   ioctl    ┌──────────────┐   SPI    ┌────────────────┐
  │ miniolt, moltd,    │──────────▶ │ /dev/fmcs_mci│─────────▶│  FMCS FPGA     │
  │ moltcmd, momci     │  0xa5…     │              │          │  (PGL50H)      │
  ├────────────────────┤            │   fmcs.ko    │          │                │
  │ PLOAM / OMCI stack │  netdev    │              │ GPIO IRQ │  16 × sub-ONU  │
  │                    │◀──────────▶│ molt_ploam   │◀─────────│                │
  │                    │            │ molt_omci    │          └────────────────┘
  └────────────────────┘            └──────────────┘
                                            │
                                     gpio bit-bang (once, at boot)
                                            ▼
                                    FPGA configuration port
                                    /lib/firmware/FTTR_TOP.sbit
```

Stock components, all reversed here:

| Artefact | What it is | Replaced by |
| --- | --- | --- |
| `lib/modules/fmcs.ko` | FPGA driver: SPI, GPIO IRQ, chardev, netdevs, genetlink | `driver/fmcs*.c` |
| `lib/modules/fpga_load.ko` | one-shot bitstream loader, GPIO bit-bang | `driver/fmcs_load.c` |
| `usr/bin/miniolt` | register and PLOAM/OMCI command line tool | `userspace/miniolt.c` |
| `lib/firmware/FTTR_TOP.sbit` | FPGA configuration bitstream | used unchanged |
| vendor web pages | `sta-fttr_molt.asp`, `sta-fttr_onu.asp` | `luci/` |

---

## State of the port

### Recovered and reproduced exactly

* **ioctl ABI** on `/dev/fmcs_mci` — all seven `0xa5`-typed commands, argument
  layouts and return conventions. Encoded once in `driver/fmcs_uapi.h` and
  proven equal to the literals in `fmcs.ko` by compile-time assertions in
  `tools/abi_static_assert.c`.
* **SPI wire protocol** — write `A8 <addr_be32> <val_be32>`; read
  `A0 <addr_be32>` → delay → `50` + 4 bytes; PLOAM transmit
  `AA 00 00 00 <13 bytes>`; PLOAM receive `A2 10 00 00 00` → delay → `52` + 13
  bytes. Every frame and every delay is transcribed from the vendor functions.
* **Bitstream load sequence** — nCONFIG pulse, status check, 8-bit MSB-first
  clock-out of the whole file, configuration-done check, reset release, with the
  vendor's hold times exposed as `/proc/fpgaLoad`.
* **Bitstream payload** — `FTTR_TOP.sbit` is fed byte-for-byte, MSB first, with
  no header stripping. See [`docs/SBIT_FORMAT.md`](docs/SBIT_FORMAT.md).
* **The vendor kernel itself** — `mtd2_kernel.bin` is decompressed to a 17 MB
  aarch64 `Image` and its **9 692 exported symbols recovered by name**, so every
  kernel API the vendor modules depend on can be read directly. See
  [`docs/VENDOR_KERNEL.md`](docs/VENDOR_KERNEL.md).
* **Device tree binding** — recovered from the DTB appended to the stock kernel
  image, including the five GPIO lines the vendor hard-coded.
* **Device and interface names** — `/dev/fmcs_mci`, `molt_ploam`, `molt_omci`,
  and the seventeen `genl_*` families.

### Not yet possible — see the dossier for the evidence

**R1 — no generic SPI master on the target kernel.** The FPGA's register
interface sits on the SoC SPI controller at `0x1fa10000` on a chip select of its
own. In the 6.18 tree that block is claimed by the SPI-NAND driver
(`airoha,en7581-snand`, covering `0x1fa10000` and `0x1fa11000`), and
`spi-airoha-snfi.c` offers no generic `spi_sync()` transfers. Until that block
serves general transfers, the driver cannot reach the FPGA registers.

Round 3 removed most of the guesswork. The stock kernel is now decompressed and
symbolised (see [`docs/VENDOR_KERNEL.md`](docs/VENDOR_KERNEL.md)), so the
vendor's own SPI core can be read directly instead of inferred. It establishes
that:

* the runtime port really is on the hardware controller, not bit-banged —
  `spi_device_init` maps physical **`0x1FA11550`**, which is *outside* the
  windows the stock device tree declares for either SPI node, so a new driver
  must map a range that actually covers it;
* the controller is driven through registers at `+0x00` (status), `+0x28`
  (chip select, packed `(cs << 9) | len`), `+0x2c`/`+0x34`/`+0x3c` (busy polls),
  `+0x38`/`+0x44` (FIFO data), `+0x40` (trigger) and `+0xE4` (enable);
* transfers are byte-at-a-time FIFO loops under a spinlock, which is the
  sharing discipline any replacement has to respect against the NAND driver.

What is still missing is the retry/timeout semantics and the exact meaning of
the enable register. `vendor/ksymtab.txt` now addresses every one of those
functions by name, so the remaining work is reading, not hunting.

The port is written so this is the **only** missing piece: register access goes
through `driver/fmcs_spi.c`, which already has two back ends behind one wire
protocol. Adding the missing master is a change to the SPI controller driver,
not to this one. `dts/h3c-fmcs.dtsi` documents both wiring options.

**R2 — the FTTR data path hook.** The vendor Ethernet driver publishes two
function-pointer globals (`hsgmii_lan_mac_{rx,tx}_h3c_fttr_hook`) and `fmcs.ko`
installs its own functions into them. The OpenWrt Airoha Ethernet driver has no
equivalent, so the sixteen sub-ONU data paths cannot flow yet. Outbound OMCI
frames are counted and dropped rather than silently queued
(`fmcs_omci_start_xmit()`).

**R5 — the register map above the driver — resolved differently.** The FPGA
register map itself is still unrecovered, but it turns out not to be the right
target. The vendor's FTTR management layer, `libminiolt_svc.so`, exposes a
complete typed service API whose output formats are already JSON, and
[`docs/MOLT_API.md`](docs/MOLT_API.md) recovers all of it: 25 commands with
their ids, the OLT and per-ONU optical fields, the sub-ONU state record, port
statistics, every enumeration, and the asynchronous notification sets. That is
the specification a LuCI application and any replacement daemon should be built
against, and it does not require knowing a single FPGA register address.

What is missing is the daemon that produces it — `moltd` needs the FMCS driver
to reach the FPGA. So the LuCI application is staged: stage 1 (driver state plus
a register console) is shipped and works as soon as the register transport
exists; stage 2 (the M-OLT panels) is specified field-for-field in
`docs/MOLT_API.md` section 8 but not yet wired, because wiring it to a daemon
that cannot run would be a mock-up rather than a feature.

---

## Layout

```
docs/REVERSE_ENGINEERING.md   the dossier: every finding and its evidence
docs/SBIT_FORMAT.md           structural analysis of FTTR_TOP.sbit
docs/MOLT_API.md              the recovered M-OLT service API and data model
docs/VENDOR_KERNEL.md         decompressing and symbolising the stock kernel
driver/fmcs_uapi.h            userspace ABI (the contract)
driver/fmcs.c                 core: chardev, ioctls, netdevs, events
driver/fmcs_spi.c             register transport: SPI device or GPIO bit-bang
driver/fmcs_load.c            bitstream loader and /proc/fpgaLoad
driver/{Kconfig,Makefile}     in-tree build glue
dts/h3c-fmcs.dtsi             device tree, with both transport wirings
userspace/miniolt.c           command line tool
openwrt/fttr-fmcs/            kernel module package
openwrt/fttr-tools/           userspace package
luci/luci-app-h3c-fttr/       LuCI application
tools/                        verification and analysis
```

## Building

In-tree, from the OpenWrt tree root:

```sh
cp -r fttr-port/driver      target/linux/airoha/files/drivers/fttr-fmcs
# add to target/linux/airoha/{an7581/,}config-6.18:
#   CONFIG_FTTR_FMCS=m
#   CONFIG_FTTR_FMCS_LOAD_AT_PROBE=y
# source the Kconfig from target/linux/airoha/modules.mk
```

or as packages, by copying `openwrt/fttr-fmcs`, `openwrt/fttr-tools` and
`luci/luci-app-h3c-fttr` into a feed and adding:

```
src-link fttr /path/to/fttr-port
```

Then add `fttr-fmcs`, `fttr-tools` and `luci-app-h3c-fttr` to the image.

Userspace alone:

```sh
cd userspace && make
```

Device tree: include `dts/h3c-fmcs.dtsi` from
`target/linux/airoha/dts/an7581-h3c-hm2004-du.dts` and delete the placeholder
`fmcs { … status = "disabled"; };` node that is there today.

## Verifying

```sh
python tools/run_checks.py     # everything below, one verdict
python tools/verify_abi.py     # ioctl numbers vs two shipped binaries
python tools/verify_molt_api.py # docs/MOLT_API.md vs libminiolt_svc.so
python tools/extract_kernel.py verify # kernel extraction + symbol table
python tools/check_c.py        # compile-time ABI assertions + miniolt
python tools/check_luci.py     # rpcd shim exercised the way rpcd calls it
```

All must exit 0. `verify_abi.py` and `verify_molt_api.py` are the load-bearing
ones. The first re-derives every ioctl number from the kernel's `_IOC` bit
layout and checks it against the compare chain in `fmcs.ko` *and* the immediates
in `miniolt`. The second re-reads the enum pointer tables, the JSON format
strings and the command catalogue straight out of `libminiolt_svc.so` and diffs
them against the reference document, so neither a transcription slip nor an
"improved" vendor spelling can survive.

## Why the vendor binaries still work

The point of reproducing the ABI rather than redesigning it is that the stock
`miniolt`, `moltd`, `moltcmd`, `momci` and the OMCI libraries keep working
against the new driver without a recompile. That is what makes this a port
rather than a rewrite, and it is why `fmcs_uapi.h` documents the vendor's
inconsistencies — including the eight-byte `_IOC` size on both PLOAM commands —
instead of quietly correcting them.

## Licensing

GPL-2.0-only, matching the vendor modules' own `license=GPL`.
